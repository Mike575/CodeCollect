Imports ZedGraph

Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ZedGraphControl1.GraphPane.Title.Text = "Sample created by wuyazhe"
        Dim list As New PointPairList()
        For x As Integer = 100 To 1000
            Dim y As Double = 270000 * Math.Pow(110, 2) * x * (1 - 0.058 * Math.Log(x)) / Math.Pow(Math.Pow(110, 2) + Math.Pow(x, 2), 1.5)
            list.Add(x, y)
        Next
        Dim myCurve As LineItem = ZedGraphControl1.GraphPane.AddCurve("My Curve", list, Color.Blue, SymbolType.Circle)
        ZedGraphControl1.AxisChange()
    End Sub
End Class
